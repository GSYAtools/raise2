// This code was generated for simulation with app4mc.sim

#pragma once

#include "SoftwareModel.h"
std::shared_ptr<Runnable> get_OS_Ops_Function();
