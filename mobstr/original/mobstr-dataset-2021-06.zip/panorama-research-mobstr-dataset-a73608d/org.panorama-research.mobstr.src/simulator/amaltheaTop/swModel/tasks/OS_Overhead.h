// This code was generated for simulation with app4mc.sim

#pragma once

#include "APP4MCsim.h"

//Task runnableA----
std::shared_ptr<Task> get_OS_Overhead();
